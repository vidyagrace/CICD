#!/bin/bash
echo "Starting Flask server..."
cd /home/ec2-user/flaskapp
nohup python3 app.py