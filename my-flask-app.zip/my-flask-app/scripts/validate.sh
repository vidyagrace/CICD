#!/bin/bash
curl -f http://localhost:5000 || exit 1